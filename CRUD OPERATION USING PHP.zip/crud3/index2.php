<?php
session_start();
foreach($_SESSION['text'] as $values){

    echo $values;
}


?>
