

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>
        .wrapper{
            width: 600px;
            margin: 0 auto;
        }
        table tr td:last-child{
            width: 120px;
        }

        

.input-group {
    margin: 10px 0px 10px 0px;
}
.input-group label {
    display: block;
    text-align: left;
    margin: 3px;
}

    </style>
    <script>
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
    

</head>
<body>
<div class="wrapper">
        <div class="container-fluid">
            <div class="row">
            <div class="mt-5 mb-3 clearfix">

<h1>CRUD OPERATION </h1>
    </div>

<?php
session_start();



if(isset($_POST['text'])){
$_text1 = $_POST['text1'];
$_text2 = $_POST['text2'];
$_text3 = $_POST['text3'];
$_Aid = md5($_text1);


 $_array = array($_text1=>array($_text1,$_text2,$_text3));



 if(isset($_SESSION['text'])){
     $_array = array_merge($_SESSION['text'],$_array);
 }
     $_SESSION['text'] = $_array;

    }
 
 if(isset($_POST['DELLA'])){
   unset($_SESSION['text']);
   

}

if(isset($_POST['DELLid'])){
    unset($_SESSION['text'][$_POST['DELLid']]);
 }
 $Name= $email = $job = '';
 

 if(isset($_POST['Editid'])){
   $Eid= $_SESSION['text'][$_POST['Editid']];
   $Name= $Eid[0];
   $email= $Eid[1];
   $job= $Eid[2];

 }
 ?>
<style>
    td{
 padding: 10px;
    }
    </style>
<table class="table">
<thead>

<tr class="table-info">
    <td>Name</td>
    <td>Email</td>
    <td>Job</td>
    <td colspan="3">Action</td>
    
    </tr>
    </thead>
<?php 
if(isset($_SESSION['text'])){



foreach($_SESSION['text'] as $ID => $values){ 
  
    ?>

    <tr>
    <td><?=$values[0];?></td>
    <td><?=$values[1];?></td>
    <td><?=$values[2];?></td>
    <td>
    



    <form method="post" class="btn btn-danger">    

    <input type="hidden" name="DELLid" Value="<?=$ID;?>" >
    <button type="submit" name="DELL" Value="Delete"  type="button" class="btn btn-danger">Delete</button>

    <!-- <input type="submit" name="DELL" Value="Delete" style="background-color: red;"> -->

    </form>
    </td>
    <td>
    <form method="post" class="btn btn-info">    

    <input type="hidden" name="Editid" Value="<?=$ID;?>" style="background-color: blue;">
    <button type="submit" name="Edit" Value="Edit"  type="button" class="btn btn-info">Update</button>


    <!-- <input type="submit" Value="Edit"> -->

    </form>
    </td>

    <td>
    <form method="post">    

    <input type="hidden" name="Readid" Value="<?=$ID;?>">
    <button type="submit" name="Readid" Value="Read"  type="button" class="btn btn-success">Read</button>



    </form>
    </td>

    </tr>
<?php }} ?>
</table><br>




    <form method="post">
    <input type="text" name="text1" value="<?=$Name; ?>">
    <input type="text" name="text2" value="<?=$email; ?>">
    <input type="text" name="text3" value="<?=$job; ?>"><br>
<br>
    <!-- <input type="submit" value="save" name="text" value="<?=$Action; ?>"> -->
   <tr><td> <button type="submit"  value="save" name="text" value="<?=$Action; ?>" class="btn btn-primary">Save</button></td>
<td>
</form>
<form method="POST">
<input type="submit" value="Delete All Data" name="DELLA">


</form></td></tr>
</div>
</div>
</div>